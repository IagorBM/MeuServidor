<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendedor</title>
    <link rel="stylesheet" href="../css/vendedor.css">
    <link rel="icon" type="image" href="tandem.png">
</head>

<body>
    <form method="post" action="pagVendedor.php">
    <header>
        <div class="navbar2">
            <div class="logos">Tandem &copy;</div>
        </div>
    </header>


    <div class="navbar">
        <nav>
            <ul>
                <h3 class="hh">O que vamos vender hoje?</h3>
            </ul>
        </nav>
    </div>

    <div class="image-container">
        <a value="P" name="tipo" class="box" href="cadastro.html">
                <img class="img1" src="prod.png" alt="Produtos">
                <h3>Produtos</h3>
                <p>Produtos em geral, como jóias, pulseiras, acessórios, sapatos, artigos decorativos, etc.</p>
        </a>

        <a name="tipo" class="box" href="">
                <img src="alimentos2.png" alt="Produto 2">
                <h3>Alimentos</h3>
                <p>Pães de forma, sucos naturais, feiras, verduras, salgados e doces.</p>
        </a>

        <a href=""  name="tipo" class="box" >
                <img src="servicos2.png" alt="Produto 3">
                <h3>Serviços</h3>
                <p>Trabalhos de Jardinagem, limpeza, trabalhos temporários, entre outros.</p>
        </a>
    </div>

    <footer>
        <p>&copy; 2024 Tandem - Conectando Negócios nas Ruas.</p>
    </footer>
    </form>
</body>

</html>

<?
extract($_POST);
 switch case()

?>